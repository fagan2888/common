stbl
====

MATLAB library for working with alpha stable distributions

For documentation see http://math.bu.edu/people/mveillet/html/alphastablepub.html
